import React from "react";
import MySkills from "../components/MySkill";

export default function Skills() {
  return (
    <div>
      <MySkills />
    </div>
  );
}
