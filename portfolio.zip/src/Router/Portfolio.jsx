import React from "react";
import Project from "../components/Project";

export default function Portfolio() {
  return (
    <>
      <Project />
    </>
  );
}
